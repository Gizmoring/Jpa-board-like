package com.springboot.board.entity;

import com.springboot.comment.entity.Comment;
import com.springboot.like.entity.Like;
import com.springboot.member.entity.Member;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
public class Board {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long boardId;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String boardContents;

    @Enumerated(EnumType.STRING)
    BoardStatus boardStatus = BoardStatus.QUESTION_REGISTERED;

    @Enumerated(EnumType.STRING)
    PrivacyStatus privacyStatus = PrivacyStatus.BOARD_PUBLIC;

    @Column(nullable = false, updatable = false)
    LocalDateTime createdAt = LocalDateTime.now();

    @Column(nullable = false, name = "LAST_MODIFIED_AT")
    LocalDateTime modifiedAt = LocalDateTime.now();

    @Column(nullable = false , name = "LIKE_COUNT")
    private int likeCount;

    @OneToMany(mappedBy = "board")
    private List<Like> likes = new ArrayList<>();

    public void setLike(Like like) {
        likes.add(like);
        if (like.getBoard() != this) {
            like.setBoard(this);
        }
    }


    @ManyToOne()
    @JoinColumn(name = "MEMBER_ID")
    private Member member;

    public void setMember(Member member) {
        this.member = member;
        if (!member.getBoards().contains(this)) {
            member.setBoard(this);
        }

    }

    @OneToMany(mappedBy = "board", cascade = CascadeType.REFRESH)
    private List<Comment> comments = new ArrayList<>();

    public void setComment(Comment comment) {
        comments.add(comment);
        if (comment.getBoard() != this) {
            comment.setBoard(this);
        }
    }


    public enum BoardStatus {
        QUESTION_REGISTERED("질문 등록 상태", 1),
        QUESTION_ANSWERED("답변 완료 상태", 2),
        QUESTION_DELETED("질문 삭제 상태", 3),
        QUESTION_DEACTIVED("질문 비활성화 상태", 4);
        @Getter
        private String status;
        @Getter
        private int stepNumber;

        BoardStatus(String status, int stepNumber) {
            this.status = status;
            this.stepNumber = stepNumber;
        }
    }

    public enum PrivacyStatus {
        BOARD_PUBLIC("전체 공개", 1),
        BOARD_SECRET("비공개", 2);
        @Getter
        private String status;

        @Getter
        private int stepNumber;

        PrivacyStatus(String status, int stepNumber) {
            this.status = status;
            this.stepNumber = stepNumber;
        }
    }


}
