package com.springboot.like.controller;

import com.springboot.like.dto.LikePostDto;
import com.springboot.like.entity.Like;
import com.springboot.like.mapper.LikeMapper;
import com.springboot.like.service.LikeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/ver1/boards/likes")
@Valid
@Slf4j
public class LikeController{
    private final LikeService likeService;

    private final LikeMapper likeMapper;

    public LikeController(LikeService likeService, LikeMapper likeMapper) {
        this.likeService = likeService;
        this.likeMapper = likeMapper;
    }

    @PostMapping
    public void postLike(@Valid @RequestBody LikePostDto likePostDto){
        Like like = likeMapper.likePostDtoToLike(likePostDto);
        likeService.clickLike(like,like.getBoard(),like.getMember());
    }
}
