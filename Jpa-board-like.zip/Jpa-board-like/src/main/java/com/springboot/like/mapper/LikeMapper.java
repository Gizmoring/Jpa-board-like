package com.springboot.like.mapper;

import com.springboot.like.dto.LikePostDto;
import com.springboot.like.entity.Like;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface LikeMapper {

    @Mapping(source = "boardId" , target = "board.boardId")
    @Mapping(source = "memberId",target = "member.memberId")
    Like likePostDtoToLike (LikePostDto likePostDto);
}
