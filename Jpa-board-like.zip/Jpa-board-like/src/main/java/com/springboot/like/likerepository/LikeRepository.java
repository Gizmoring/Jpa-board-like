package com.springboot.like.likerepository;

import com.springboot.like.entity.Like;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;


public interface LikeRepository extends JpaRepository<Like,Long> {
    @Query("SELECT l FROM Like l WHERE l.board.id = :boardId AND l.member.id = :memberId")
    Optional<Like> findByBoardIdAndMemberId(@Param("boardId") Long boardId, @Param("memberId") Long memberId);
}
