package com.springboot.like.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class LikePostDto {
    private long boardId;
    private long memberId;
}
