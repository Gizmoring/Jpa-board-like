package com.springboot.like.entity;
import com.springboot.board.entity.Board;
import com.springboot.member.entity.Member;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "LIKES")
@NoArgsConstructor
public class Like {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long likeId;

    @ManyToOne
    @JoinColumn(name = "MEMBER_ID")
    private Member member;

    @ManyToOne()
    @JoinColumn(name = "BOARD_ID")
    private Board board;

    public void setBoard(Board board){
        this.board = board;
        if(board.getLikes().contains(this)){
            board.setLike(this);
        }
    }

}
