package com.springboot.like.service;

import com.springboot.board.entity.Board;
import com.springboot.board.repository.BoardRepository;
import com.springboot.board.service.BoardService;
import com.springboot.like.entity.Like;
import com.springboot.like.likerepository.LikeRepository;
import com.springboot.member.entity.Member;
import com.springboot.member.service.MemberService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LikeService {
    LikeRepository likeRepository;
    MemberService memberService;
    BoardService boardService;
    BoardRepository boardRepository;

    public LikeService(LikeRepository likeRepository, MemberService memberService, BoardService boardService, BoardRepository boardRepository) {
        this.likeRepository = likeRepository;
        this.memberService = memberService;
        this.boardService = boardService;
        this.boardRepository = boardRepository;
    }

    // 없으면 생성하고 있으면 지운다 그래서 보드1 멤버1 의 like는 0 or 1일 수 밖에 없다.
//    좋아요 수는 List<Like> likes 의 사이즈를 조회해서 보드에서 리스폰스 주게 구현할 것
//  DB에서 Like여부를 Optional 클래스로 불러와서 검증하는 메서드를 짜고 예외는 각 보드,멤버 서비스에서 던져주겠따.
// boardService.verifyBoardStatus(long boardId) 활용 보드 비활, 삭제 상태에 따라 예외를 던져줌
// 보드상태가 비활성화, 삭제 일때는 좋아요를 못 누르게 해야한다.
    public void clickLike(Like like, Board board, Member member) {
        boardService.verifyBoardStatusAndPrivacyStatus(board.getBoardId());
        memberService.verifyMemberStatus(member);
        memberService.findVerifiedMember(member.getMemberId());

        Optional<Like> optionalLike = likeRepository.findByBoardIdAndMemberId(board.getBoardId(), member.getMemberId());

        if (optionalLike.isPresent()) {
            likeRepository.deleteById(optionalLike.get().getLikeId());
            Board findBoard = boardService.findVerifyExistBoard(board.getBoardId());
            findBoard.setLikeCount(findBoard.getLikeCount() - 1);
            boardRepository.save(findBoard);


        } else {
            like.setBoard(board);
            likeRepository.save(like);
            Board findBoard = boardService.findVerifyExistBoard(board.getBoardId());
            findBoard.setLikeCount(findBoard.getLikeCount() + 1);
            boardRepository.save(findBoard);
        }

    }
}

//{1번 안 실패함..
//        //        보드가 있는지, 보드의 상태가 활성화가 되어있는지 확인하는 검증 메서드
//
//        like.setBoard(board);
//        boardService.verifyBoardStatus(board.getBoardId());
//        //        멤버가 들어왔을 때 멤버가 있는지, 멤버의 상태의 여부를 확인하는 검증메서드
//        memberService.verifyMemberStatus(member);
////        db에서 boardId와 memberId로 찾은 Like가 존재한다면 지우고 없다면 저장한다.
//        Optional<Like> optionalLike = likeRepository.findByBoardIdAndMemberId(board.getBoardId(), member.getMemberId());
//
//        optionalLike.ifPresentOrElse(
//                findLike -> likeRepository.deleteById(findLike.getLikeId()),
//                () -> likeRepository.save(like)
//        );
//              db에 좋아요 수까지는 저장이 잘 되나 안에 board 테이블에 likeCount가 늘어나지는 않음
//        Board findBoard = boardService.findVerifyExistBoard(board.getBoardId());
//
//        findBoard.setLikeCount(findBoard.getLikes().size());}