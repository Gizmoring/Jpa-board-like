package com.springboot.member.service;

import com.springboot.board.entity.Board;
import com.springboot.board.repository.BoardRepository;
import com.springboot.board.service.BoardService;
import com.springboot.exception.BusinessLogicException;
import com.springboot.exception.ExceptionCode;
import com.springboot.member.entity.Member;
import com.springboot.member.repository.MemberRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MemberService {
    private final MemberRepository memberRepository;

    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }


    public Member createMember(Member member) {
        verifyExistEmail(member.getEmail());
        return memberRepository.save(member);
    }

    public Member updatedMember(Member member) {
        Member findMember = verifyMemberStatus(member);
        Optional.ofNullable(member.getName())
                .ifPresent(name -> findMember.setName(name
                ));
        Optional.ofNullable(member.getEmail())
                .ifPresent(email -> findMember.setEmail(email));
        Optional.ofNullable(member.getPhone())
                .ifPresent(phone -> findMember.setPhone(phone
                ));
        Optional.ofNullable(member.getMemberStatus())
                .ifPresent(memberStatus -> findMember.setMemberStatus(memberStatus
                ));

        findMember.setModifiedAt(LocalDateTime.now());
        return memberRepository.save(findMember);


    }

    public Member findMember(long memberId) {
        Member findMember = findVerifiedMember(memberId);
        return verifyMemberStatus(findMember);
    }

    public void deleteMember(long memberId) {
        Member findMember = verifyMemberStatus(findVerifiedMember(memberId));
        findMember.setMemberStatus(Member.MemberStatus.MEMBER_QUIT);
        findMember.getBoards().forEach(board -> board.setBoardStatus(Board.BoardStatus.QUESTION_DEACTIVED));
        findMember.getBoards().forEach(board -> board.setPrivacyStatus(Board.PrivacyStatus.BOARD_SECRET));
        memberRepository.save(findMember);

    }

    public void verifyExistEmail(String email) {
        Optional<Member> findByEmail = memberRepository.findByEmail(email);
        if (findByEmail.isPresent()) {
            throw new BusinessLogicException(ExceptionCode.MEMBER_EXISTS);
        }
    }

    public Member findVerifiedMember(long memberId) {
        Optional<Member> findByIdMember = memberRepository.findById(memberId);
        return findByIdMember.orElseThrow(() -> new BusinessLogicException(ExceptionCode.MEMBER_NOT_FOUND));
    }

    public Member verifyMemberStatus(Member member) {
        Member findMember = findVerifiedMember(member.getMemberId());
        if (!findMember.getMemberStatus().equals(Member.MemberStatus.MEMBER_ACTIVE)) {
            throw new BusinessLogicException(ExceptionCode.MEMBER_NOT_FOUND);
        }
        return findMember;
    }

}
